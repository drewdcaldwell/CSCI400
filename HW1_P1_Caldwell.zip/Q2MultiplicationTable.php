<!DOCTYPE html>

<!--
Q2 on HW1_P1 for CSCI-C400 Client-Server Web Programming at IU-Kokomo
Drew D. Caldwell                              1/20/2024               
-->

<html>
   <head>
      <meta charset = "utf-8" />
      <title>Q2 Multiplication Table</title>
	  <link rel="stylesheet" type="text/css" href="common.css" />
   </head>

   <body>
     <!-- Header of the Website in php -->
	  <h3><?php echo "Welcome to my Multiplication Table Website"; ?></h3>
     <!-- Purpose of the code/website -->
	  <p>
      Here is a multiplication table using a php for loop to calculate and output in HTML table format. THe purpose of this
      website is to create a user friendly experience when it come to finding a number multiplied by a positive multiple of 10. The purpose of
      this code is to become familiar with php, and inputing values into an HTML format.
     </p>

     <!-- Initialize the border size of the HTML table -->
     <table border="1">
      <!-- Set the headers of the columns to a user friendly format -->
   <tr>
        <!-- Column 1 Header -->
        <th>N</th>
        <!-- Column 2 Header -->
        <th>N*10</th>
        <!-- Column 3 Header -->
        <th>N*100</th>
        <!-- Column 4 Header -->
        <th>N*1000</th>
    </tr>

      <!-- This is the for loop that outputs values into our HTML table -->
    <?php
        for ($i = 1; $i <= 7; $i++) {
            //Begin Row Output
            echo "<tr>";
            //This is the first column output
            echo "<td>$i</td>";
            //This is the second column output
            echo "<td>" . ($i * 10) . "</td>";
            //This is the third column output
            echo "<td>" . ($i * 100) . "</td>";
            //This is the fourth column output
            echo "<td>" . ($i * 1000) . "</td>";
            //End Row Output
            echo "</tr>";
        }
    ?>
   <!-- End HTML table environment -->
   </table>   
   <!-- Notations and reflections about this problem -->
   <p>
      The biggest difficulty I faced during this question was the output. At first I began by creating a single array
      and altering the array to get the desired ouptut. After doing this, and reading about how to use an html table, I was
      able to understand how to input into the HTML table, so I was able to make the code much smaller after.
   </p>
   </body>
</html>
