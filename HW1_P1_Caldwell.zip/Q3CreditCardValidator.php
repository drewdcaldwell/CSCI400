<!DOCTYPE html>

<!--
This is an example of Sequential Problem #1 done in class
We will use php to compute the average velocity
-->

<html>
   <head>
      <meta charset = "utf-8" />
      <title>Credit Card Validator</title>
	  <link rel="stylesheet" type="text/css" href="common.css" />
   </head>

   <body>
      <h3><?php echo "Credit Card Number Tester"; ?></h3>
         <?php 
         // create the test case variables
         // Card Number 1 should pass, Card Number 2 should pass, and Card Number 3 should not pass
         $creditCardNumber1 = "5555-6666-7777-8888";
         $creditCardNumber2 = "5678 9012 3456 7890";
         $creditCardNumber3 = "123A 8765 5612 8945";

         // Run the code for creditCardNumber 1
         // If you want to change the test, change the card number variable in the trim function below
         // Trim the card number, this will get rid of spaces before and after any characters, digits, or special characters
         $trimmedCardNumber  = trim($creditCardNumber1);
          
         //The next two str_replace functions remove dashes, and then remove spaces, and replaces them with empty spaces
         // that concatenate values together, hopefully, forming a digit
         $clearCardNumber = str_replace('-','', $trimmedCardNumber);
         $testableCardNumber = str_replace(' ','', $clearCardNumber);

         // This if else function determines if the string, after removing spaces and dashes, is a digit
         // This will display the card number if it is a digit, and will output an error message if not
         if (ctype_digit($testableCardNumber)) {
            echo "This is a valid Credit Card. Card Number: $testableCardNumber";
        } else {
            echo "Invalid Credit Card. Card Number contains non-numeric characters.";
        }

         ?>
   </body>
</html>
