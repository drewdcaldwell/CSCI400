<!DOCTYPE html>

<!--
Q1 Hw1_P1 CSCI-C400 Client - Server Web Programming
Drew Caldwell 1/22/2024 IU-Kokomo
THe purpose of this program is to calculate the number of pounds lost after
excercising
 -->

<html>
   <head>
      <meta charset = "utf-8" />
      <title>Weightloss Calculator</title>
	  <link rel="stylesheet" type="text/css" href="common.css" />
   </head>

   <body>
      <!-- Rewriting the question for reference later-->
	  <p><b>Q1.</b> The number of calories burned per hour by bicycling, jogging, and swimming is 200, 475, and 275, respectively. 
      A person loses 1 pound of weight for each 3500 calories burned. Write a program that allows the user to input the number of 
      hours spent at each activity and then calculates the number of pounds worked off. </b>
      </p>  
      <!-- Defining my "user" input. This is where I would need to add code to get user input if that was the case. -->
         <p>
            Using an assumed amount of 2 hours biking, 1 hour running, and 3 hours swimming, using our php code, we may compute.
         </p>
         <?php 
            //Define the variables for number of calories burned per hour of each excercise
            $bikeCalories = 200;
            $jogCalories = 475;
            $swimCalories = 275;

            // Define the variables for the user input, how many hours per activity
            $bikeHours = 2;
            $jogHours = 1;
            $swimHours = 3;

            // Define the number of calories in a pound
            $caloriesPerPound = 3500;
         
            // Define a variable for the number of pounds lost, and calculate the value.
            $poundsLost = ($bikeCalories*$bikeHours +$jogCalories*$jogHours +$swimCalories*$swimHours)/$caloriesPerPound;

          // Output the result for the user
            echo "<p> The number of pounds lost when biking for $bikeHours hours, jogging for $jogHours hours, and swimming for $swimHours hours, is $poundsLost pounds.</p>";
         ?>
   </body>
</html>
